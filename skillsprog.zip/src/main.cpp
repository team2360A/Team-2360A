/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition     Competition;
motor           DriveFrontLeft      = motor(PORT1);
motor           DriveBackLeft       = motor(PORT2, true);
motor           DriveFrontRight     = motor(PORT3, true);
motor           DriveBackRight      = motor(PORT5);
motor           Tray                = motor(PORT7);
motor           Arm                 = motor(PORT8);
motor           IntakeLeft          = motor(PORT15);
motor           IntakeRight         = motor(PORT12, true);
controller      Controller1;


void yeet(){
Tray.spin(directionType::fwd, 95, pct);
wait(2, seconds);
Tray.stop(brake);
}

int main();
  int      trayUpSpeedPCT     = 50;
  int      trayDownSpeedPCT   = 95;
  int      armSpeedPCT        = 95;
  int      intkSpeedPCT       = 95;
  int      outkSpeedPCT       = 30;
  int            drivespd     = 85;
  double   speedModifier      = 0.8;

void go(float time){
 DriveFrontRight.spin(vex::directionType::fwd, 50, vex::velocityUnits::pct);
 DriveFrontLeft.spin(vex::directionType::fwd, 50, vex::velocityUnits::pct);
 DriveBackRight.spin(vex::directionType::fwd, 50, vex::velocityUnits::pct);
 DriveBackLeft.spin(vex::directionType::fwd, 50, vex::velocityUnits::pct);
 vex::task::sleep(time);
}
void goback(float time){
 DriveBackRight.spin(vex::directionType::rev, drivespd, vex::velocityUnits::pct);
 DriveBackLeft.spin(vex::directionType::rev, drivespd, vex::velocityUnits::pct);
  DriveFrontRight.spin(vex::directionType::rev, drivespd, vex::velocityUnits::pct);
 DriveFrontLeft.spin(vex::directionType::rev, drivespd, vex::velocityUnits::pct);
 vex::task::sleep(time);
}
void stop(){
 DriveFrontRight.stop(vex::brakeType::brake);
 DriveBackLeft.stop(vex::brakeType::brake);
 DriveBackRight.stop(vex::brakeType::brake);
 DriveFrontLeft.stop(vex::brakeType::brake);
}
void gotray(float time){
 Tray.spin(vex::directionType::rev, trayUpSpeedPCT, vex::velocityUnits::pct);
 vex::task::sleep(time);
}
void revtray(float time){
 Tray.spin(vex::directionType::rev,trayDownSpeedPCT, vex::velocityUnits::pct);
 vex::task::sleep(time);
}
void stoptray(){
 Tray.stop(vex::brakeType::brake);
}
void intin(float time){
 IntakeLeft.spin(vex::directionType::fwd, outkSpeedPCT, vex::velocityUnits::pct);
 IntakeRight.spin(vex::directionType::fwd, outkSpeedPCT, vex::velocityUnits::pct);
 vex::task::sleep(time);
}
void intout(float time){
 IntakeLeft.spin(vex::directionType::rev, outkSpeedPCT, vex::velocityUnits::pct);
 IntakeRight.spin(vex::directionType::rev, outkSpeedPCT, vex::velocityUnits::pct);
 vex::task::sleep(time);
}
void intstop(float time){
 IntakeLeft.spin(vex::directionType::rev, outkSpeedPCT, vex::velocityUnits::pct);
 IntakeRight.spin(vex::directionType::rev, outkSpeedPCT, vex::velocityUnits::pct);
 vex::task::sleep(time);
}


/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  

}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous (void) {
    uint8_t buf[6000];
    Brain.SDcard.loadfile("skillsprogram.txt", buf, 6000);
    
    for (int i = 0; i < 6000; i+= 5) 
    {    
        DriveFrontLeft.spin(vex::directionType::fwd, buf[i] - 100, vex::velocityUnits::pct);
        DriveFrontRight.spin(vex::directionType::fwd, buf[i + 1] - 100, vex::velocityUnits::pct);
        DriveBackLeft.spin(vex::directionType::fwd, buf[i] - 100, vex::velocityUnits::pct);
        DriveBackRight.spin(vex::directionType::fwd, buf[i + 1] - 100, vex::velocityUnits::pct);
        Arm.spin(vex::directionType::fwd, buf[i + 2] - 100, vex::velocityUnits::pct);
        Tray.spin(vex::directionType::fwd, buf[i + 3] - 100, vex::velocityUnits::pct);
        IntakeLeft.spin(vex::directionType::fwd, buf[i + 4] - 100, vex::velocityUnits::pct);
        IntakeRight.spin(vex::directionType::fwd, buf[i + 4] - 100, vex::velocityUnits::pct);
                
        vex::task::sleep(25/2);
    }
 
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
  

void usercontrol(void) {

  
  while(1){

    //Drive Control Code: Axies
      DriveFrontLeft.spin(directionType::fwd, Controller1.Axis3.position()*speedModifier, pct);
      DriveBackLeft.spin(directionType::fwd, Controller1.Axis3.position()*speedModifier, pct);
      DriveFrontRight.spin(directionType::fwd, Controller1.Axis2.position()*speedModifier, pct);
      DriveBackRight.spin(directionType::fwd, Controller1.Axis2.position()*speedModifier, pct);

    //Set Speed: L1/L2
      if(Controller1.ButtonL1.pressing()) {
        speedModifier=0.8;
      }
      else
      if(Controller1.ButtonL2.pressing()) {
        speedModifier=0.4;
      }

    //Tray Lift Code: Up/Down
      if(Controller1.ButtonUp.pressing()) {
        Tray.spin(directionType::fwd, trayUpSpeedPCT, pct);
      }
      else
      if(Controller1.ButtonDown.pressing()) {
        Tray.spin(directionType::rev, trayDownSpeedPCT, pct);
      }
      else {
        Tray.stop(brake);
      }

    //Run yeet: Y
    if(Controller1.ButtonY.pressing()) {
      yeet();
    }
    
    //Arm Lift Code: X/B
      if(Controller1.ButtonB.pressing()) {
        Arm.spin(directionType::fwd, armSpeedPCT, pct);
      }
      else
      if(Controller1.ButtonX.pressing()) {
        Arm.spin(directionType::rev, armSpeedPCT, pct);
      }
      else {
        Arm.stop(brake);
      }

    //Intake Code: R1/R2
      if(Controller1.ButtonR1.pressing()) {
        IntakeLeft.spin(directionType::fwd, intkSpeedPCT, pct);
        IntakeRight.spin(directionType::fwd, intkSpeedPCT, pct);
      }
      else
      if(Controller1.ButtonR2.pressing()) {
        IntakeLeft.spin(directionType::rev, outkSpeedPCT, pct);
        IntakeRight.spin(directionType::rev, outkSpeedPCT, pct);
      }
      else {
        IntakeLeft.stop(brake);
        IntakeRight.stop(brake);
      }
      
    wait(20, msec);
    
  }

  vexcodeInit();
  
}

int main(){

  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }

  
}




