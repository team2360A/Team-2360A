/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Burak.A                                                   */
/*    Created:      Thu Sep 26 2019                                           */
/*    Last Edited:  2/22/2020                                                 */
/*                                                                            */
/*----------------------------------------------------------------------------*/
// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----
#include "vex.h"
using namespace vex;
// A global instance of competition
competition Competition;
motor           DriveFrontLeft      = motor(PORT1);
motor           DriveBackLeft       = motor(PORT2, true);
motor           DriveFrontRight     = motor(PORT3, true);
motor           DriveBackRight      = motor(PORT5);
motor           Tray                = motor(PORT7);
motor           Arm                 = motor(PORT8);
motor           IntakeLeft          = motor(PORT15);
motor           IntakeRight         = motor(PORT12, true);
brain           Brain;
controller      Controller1;

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*---------------------------------------------------------------------------*/

void yeet()
{
Tray.spin(directionType::fwd, 95, pct);
wait(2, seconds);
Tray.stop(brake);
}

int main() 
{
    uint8_t data[3000];
    Controller1.Screen.clearScreen();
    for(int count = 5; count > 0; count--)
    {
      Controller1.Screen.clearLine(1);
      Controller1.Screen.setCursor(1, 1);
      Controller1.Screen.print(count);
      vex::task::sleep(1000);
    }
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.print("Recording");

  int      trayUpSpeedPCT     = 50;
  int      trayDownSpeedPCT   = 95;
  int      armSpeedPCT        = 95;
  int      intkSpeedPCT       = 95;
  int      outkSpeedPCT       = 30;
  double   speedModifier      = 0.8;
    for (int i = 0; i < 3000; i+= 5) 
    {
        //Insert Controls Here:

    //Drive Control Code: Axies
      DriveFrontLeft.spin(directionType::fwd, Controller1.Axis3.position()*speedModifier, pct);
      DriveBackLeft.spin(directionType::fwd, Controller1.Axis3.position()*speedModifier, pct);
      DriveFrontRight.spin(directionType::fwd, Controller1.Axis2.position()*speedModifier, pct);
      DriveBackRight.spin(directionType::fwd, Controller1.Axis2.position()*speedModifier, pct);

    //Set Speed: L1/L2
      if(Controller1.ButtonL1.pressing()) {
        speedModifier=0.8;
      }
      else
      if(Controller1.ButtonL2.pressing()) {
        speedModifier=0.4;
      }

    //Tray Lift Code: Up/Down
      if(Controller1.ButtonUp.pressing()) {
        Tray.spin(directionType::fwd, trayUpSpeedPCT, pct);
      }
      else
      if(Controller1.ButtonDown.pressing()) {
        Tray.spin(directionType::rev, trayDownSpeedPCT, pct);
      }
      else {
        Tray.stop(brake);
      }

    //Run yeet: Y
    if(Controller1.ButtonY.pressing()) {
      yeet();
    }
    
    //Arm Lift Code: X/B
      if(Controller1.ButtonB.pressing()) {
        Arm.spin(directionType::fwd, armSpeedPCT, pct);
      }
      else
      if(Controller1.ButtonX.pressing()) {
        Arm.spin(directionType::rev, armSpeedPCT, pct);
      }
      else {
        Arm.stop(brake);
      }

    //Intake Code: R1/R2
      if(Controller1.ButtonR1.pressing()) {
        IntakeLeft.spin(directionType::fwd, intkSpeedPCT, pct);
        IntakeRight.spin(directionType::fwd, intkSpeedPCT, pct);
      }
      else
      if(Controller1.ButtonR2.pressing()) {
        IntakeLeft.spin(directionType::rev, outkSpeedPCT, pct);
        IntakeRight.spin(directionType::rev, outkSpeedPCT, pct);
      }
      else {
        IntakeLeft.stop(brake);
        IntakeRight.stop(brake);
      }
    
        data[i] = (uint8_t) (DriveFrontLeft.velocity(vex::velocityUnits::pct) + 100);
        data[i + 1] = (uint8_t) (DriveFrontRight.velocity(vex::velocityUnits::pct) + 100);
        data[i + 2] = (uint8_t) (Arm.velocity(vex::velocityUnits::pct) + 100);
        data[i + 3] = (uint8_t) (Tray.velocity(vex::velocityUnits::pct) + 100);
        data[i + 4] = (uint8_t) (IntakeLeft.velocity(vex::velocityUnits::pct) + 100);
        vex::task::sleep(100);
    }
    //Changing "data.txt" will change the savefile name, this will allow multiple recordings 
    Brain.SDcard.savefile("skillsprogram.txt", data, 3000);
}
